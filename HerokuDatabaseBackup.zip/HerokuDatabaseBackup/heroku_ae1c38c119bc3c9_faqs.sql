-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2023 at 12:49 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drawsome`
--

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(11) NOT NULL,
  `faq_title` varchar(255) NOT NULL,
  `faq_description` varchar(255) NOT NULL,
  `faq_type` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `faq_title`, `faq_description`, `faq_type`, `created_at`) VALUES
(44, 'Why can’t I see the drawer’s social media?', 'The pop up will be available after the 60 second drawing. Some submitters may also choose to make their social media private.', 'NormalFAQ', '2023-02-01 06:12:52'),
(54, 'Why is my video not playing?', 'Each device will only allow for 1 play per day. Once you’ve started the video you cannot pause or stop. You’ll have to try again for the next day.', 'NormalFAQ', '2023-02-01 06:13:12'),
(64, 'Why can’t I see the user’s name?', 'Submitters have the option to be anonymous therefore on some days you might not sell the drawer information.', 'NormalFAQ', '2023-02-01 06:13:38'),
(74, 'Am I allowed to play and submit on the same day?', 'yes', 'NormalFAQ', '2023-02-01 06:14:03'),
(84, 'How many drawings can I submit?', 'You can submit up to 1 drawing per day. You can redo your drawing but once you hit submit your drawing is locked in for the day’s entry.', 'SubmitterFAQ', '2023-02-01 06:14:26'),
(94, 'When will I find out if my drawing is accepted?', 'You will receive an email at least 3-5 days before your drawing was chosen with details on live date. ', 'SubmitterFAQ', '2023-02-01 06:14:43'),
(104, 'Are there any photos not allowed?', 'You’ll must keep your  entries friendly without any sexual, violent, or disturbing content. We may  ban your username if policy is broken.', 'SubmitterFAQ', '2023-02-01 06:15:00'),
(114, 'Will I find out if my drawing is not accepted?', 'Just because you weren’t chosen doesn’t mean we don’t love you. We anticipate receiving more inquires than total slots available. We will send out a kind email informing you to try again =)', 'SubmitterFAQ', '2023-02-01 06:15:30'),
(124, 'How to Play?', 'Test', 'NormalFAQ', '2023-02-14 13:18:03'),
(134, 'How to Play?', 'Test', 'NormalFAQ', '2023-02-14 13:18:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
