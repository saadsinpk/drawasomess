import React from 'react'

function DashboardLayout() {
  return (
    <div>DashboardLayout</div>
  )
}

export default DashboardLayout