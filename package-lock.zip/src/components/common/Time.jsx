import React from 'react'

function Time() {
  return (
    <div className='timeMian my-4 text-center'>
        <h4 >Your Time Today</h4>
        <h2 className=''>15.32 secs</h2>
    </div>
  )
}

export default Time