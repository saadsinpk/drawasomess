import React from 'react'
import Header2 from './components/common/Header2';
import img1 from './components/dist/webImages/1.png';
import { FaPlay } from "react-icons/fa";

function Submission() {
  return (
   <>
   <Header2  />
   <div className="diagramMain p-4">
    <img src={img1} alt="" />
    <div className='flex items-center justify-between w-100'>
    <div className="colorMain flex items-center gap-2">
    <div className='playbtn'><FaPlay /></div>
    <div className="colorMainB">
            <h5>color</h5>
        <div className="colorMainBox flex  justify-center gap-1">
            <div className="colorMainBox_" style={{background:"#377E22"}}> </div>
            <div className="colorMainBox_" style={{background:"#EA3323"}}> </div>
            <div className="colorMainBox_" style={{background:"#0000F5"}}> </div>
            <div className="colorMainBox_" style={{background:"#FFFFFF"}}> </div>
            <div className="colorMainBox_" style={{background:"#000000"}}> </div>
        </div>
        </div>
        </div>
        <div className='size text-center'>
            <p className='m-0'>SIZE</p>
            <div className="sizeB flex items-center gap-2">
            <div className="sizeBox active"></div>
            <div className="sizeBox"></div>
            <div className="sizeBox"></div>
            <div className="sizeBox"></div>
            <div className="sizeBox"></div>
            </div>
        </div>
  
   </div>
   </div>
   </>
  )
}

export default Submission