import React from "react";
import { Routes, Route } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import { injectStyle } from "react-toastify/dist/inject-style";
import WebLayout from "./routes/WebLayout";
import LoginLayout from "./routes/LoginLayout";
import DashboardLayout from "./routes/DashboardLayout";
function App() {
  injectStyle();
  return (
    <>
        <Routes>
            <Route path="/admin/dasboard" element={<DashboardLayout />} />
            <Route path="/admin/login" element={<LoginLayout />} />
            <Route path="*" element={<WebLayout />} />
          </Routes>
            <ToastContainer />
    </>
  );
}

export default App;
